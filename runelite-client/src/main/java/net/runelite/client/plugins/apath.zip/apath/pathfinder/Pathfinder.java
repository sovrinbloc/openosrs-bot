package net.runelite.client.plugins.apath.pathfinder;

import lombok.Getter;
import net.runelite.api.coords.WorldPoint;
import net.runelite.client.plugins.apath.APathPlugin;

import java.util.*;

enum PlayerMovementStyle
{
	WALK,
	RUN,
	CRAWL
}

public class Pathfinder
{
	private final CollisionMap map;
	private final Node start;
	private final WorldPoint target;
	private final List<Node> boundary = new LinkedList<>();
	private final Set<WorldPoint> visited = new HashSet<>();
	private final Map<WorldPoint, List<WorldPoint>> transports;
	private final boolean avoidWilderness;
	@Getter
	private boolean hasTransport = false;
	private Node nearest;

	public static final float TILES_PER_TICK_RUN = 2.0f;
	public static final float TILES_PER_TICK_WALK = 1.0f;
	public static final float TILES_PER_TICK_CRAWL = 0.5f;
	public static final float TIME_PER_CLICK = 0.6f;

	public Pathfinder(CollisionMap map, Map<WorldPoint, List<WorldPoint>> transports, WorldPoint start, WorldPoint target, boolean avoidWilderness)
	{
		this.map = map; // collision map
		this.transports = transports; // doors and other objects that transport the player
		this.target = target; // the target location
		this.start = new Node(start, null); // the starting position of the player
		this.avoidWilderness = avoidWilderness;
		nearest = null;
	}

	public List<WorldPoint> find()
	{
		boundary.add(start);

		int bestDistance = Integer.MAX_VALUE;

		while (!boundary.isEmpty())
		{
			// removes the location node from the "boundary" list, and assigns it to node
			Node node = boundary.remove(0);

			if (node.position.equals(target))
			{
				return node.path();
			}

			// gets the distance from the current node to the target
			int distance = Math.max(Math.abs(node.position.getX() - target.getX()), Math.abs(node.position.getY() - target.getY()));

			// if the distance is less than the previous best distance, assign the node as the nearest
			if (nearest == null || distance < bestDistance)
			{
				nearest = node;
				bestDistance = distance;
			}

			addNeighbors(node);
		}

		if (nearest != null)
		{
			return nearest.path();
		}

		return null;
	}

	private void addNeighbors(Node node)
	{
		if (map.w(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() - 1, node.position.getY(), node.position.getPlane()));
		}

		if (map.e(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() + 1, node.position.getY(), node.position.getPlane()));
		}

		if (map.s(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX(), node.position.getY() - 1, node.position.getPlane()));
		}

		if (map.n(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX(), node.position.getY() + 1, node.position.getPlane()));
		}

		if (map.sw(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() - 1, node.position.getY() - 1, node.position.getPlane()));
		}

		if (map.se(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() + 1, node.position.getY() - 1, node.position.getPlane()));
		}

		if (map.nw(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() - 1, node.position.getY() + 1, node.position.getPlane()));
		}

		if (map.ne(node.position.getX(), node.position.getY(), node.position.getPlane()))
		{
			addNeighbor(node, new WorldPoint(node.position.getX() + 1, node.position.getY() + 1, node.position.getPlane()));
		}

		for (WorldPoint transport : transports.getOrDefault(node.position, new ArrayList<>()))
		{
			addNeighbor(node, transport);
			hasTransport = true;
		}
	}

	public List<WorldPoint> currentBest()
	{
		return nearest == null ? null : nearest.path();
	}

	/**
	 * Adds the neighbor CLOSEST to the target.
	 *
	 * @param node
	 * @param neighbor
	 */
	private void addNeighbor(Node node, WorldPoint neighbor)
	{
		if (avoidWilderness && APathPlugin.isInWilderness(neighbor))
		{
			return;
		}

		if (!visited.add(neighbor))
		{
			return;
		}

		boundary.add(new Node(neighbor, node));
	}


	public float steps()
	{
		return this.boundary.size();
	}

	public float time(PlayerMovementStyle movementStyle)
	{
		switch (movementStyle)
		{
			case CRAWL:
				return boundary.size() * TILES_PER_TICK_CRAWL;
			case WALK:
				return boundary.size() * TILES_PER_TICK_WALK;
			case RUN:
				return boundary.size() * TILES_PER_TICK_RUN;
		}
		return -1;
	}

	private static class Node
	{
		public final WorldPoint position;
		public final Node previous;

		public Node(WorldPoint position, Node previous)
		{
			this.position = position;
			this.previous = previous;
		}

		/**
		 * Traverses through the linkedlist and actually returns the step by
		 * step path to the location.
		 * todo: is this to or from the location?
		 *
		 * @return
		 */
		public List<WorldPoint> path()
		{
			List<WorldPoint> path = new LinkedList<>();
			Node node = this;

			while (node != null)
			{
				path.add(0, node.position);
				node = node.previous;
			}

			return new ArrayList<>(path);
		}
	}
}